package com.prog3.tp1.Entities;

import jakarta.persistence.*;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Producto extends baseEntidad {
    @Enumerated(EnumType.STRING)
    private Producto.tipo tipo;
    private int tiempoEstimadoCocina;
    private String denominacion;
    private Double precioVenta;
    private Double precioCompra;
    private int stockActual;
    private int stockMinimo;
    private String unidadMedida;
    private String foto;
    private String receta;
    public enum tipo{
        MANUFACTURADO,INSUMO;
    }

}

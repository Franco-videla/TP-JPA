package com.prog3.tp1.Entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Domicilio extends baseEntidad{
    private String calle;
    private String numero;
    private String localidad;


    @ManyToOne()
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.EAGER)
    @JoinColumn(name = "domicilio_id")
    @Builder.Default
    private List<Pedido> pedidos =new ArrayList<>();
    public void agregarPedidoD(Pedido pedi){
        pedidos.add(pedi);
    }
    public void mostrarPedidosD(){
        System.out.println("Pedidos de la calle: " + calle+" "+numero);
        for (Pedido pedido : pedidos) {
            System.out.println("Fecha: " + pedido.getFecha() + "\nEstado: " +pedido.getEstado()+"\nhora estimada de la entrega: "+pedido.getHoraEstimadaEntrega());
            System.out.println("Tipo de envio: "+pedido.getTipoEnvio()+"\nTotal: "+pedido.getTotal());
        }
    }

}

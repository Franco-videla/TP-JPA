package com.prog3.tp1.Entities;

import jakarta.persistence.Entity;
import lombok.*;


@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ConfigGral extends baseEntidad{
private int cantidadCocineros;
private String emailEmpresa;
private String tokenMercadoPago;
}

package com.prog3.tp1.Repositories;

import com.prog3.tp1.Entities.DetallePedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface detallepedidoRepository extends JpaRepository<DetallePedido,Long> {
}

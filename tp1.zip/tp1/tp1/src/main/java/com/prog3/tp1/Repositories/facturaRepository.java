package com.prog3.tp1.Repositories;

import com.prog3.tp1.Entities.Factura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface facturaRepository extends JpaRepository<Factura,Long> {
}

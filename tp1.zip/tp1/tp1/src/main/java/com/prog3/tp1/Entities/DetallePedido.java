package com.prog3.tp1.Entities;

import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetallePedido extends baseEntidad {
    private int cantidad;
    private Double subtotal;


    @ManyToOne()
    @JoinColumn(name = "producto_id")
    private Producto producto;
}

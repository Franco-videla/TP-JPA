package com.prog3.tp1.Repositories;

import com.prog3.tp1.Entities.Domicilio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface domicilioRepository extends JpaRepository<Domicilio,Long> {
}

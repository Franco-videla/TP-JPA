package com.prog3.tp1.Entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Pedido  extends baseEntidad{

    private String fecha;
    @Enumerated(EnumType.STRING)
    private Estado estado;
    private LocalDateTime horaEstimadaEntrega;
    @Enumerated(EnumType.STRING)
    private TipoEnvio tipoEnvio;
    private Double total;

    public enum Estado{
        INICIADO,PREPARACION,ENTREGADO;
    }
    public enum TipoEnvio{
        DELIBERY,RETIRADA;
    }


    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "factura_id")
    private Factura factura;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.EAGER)
    @JoinColumn(name = "pedido_id")
    @Builder.Default
    private List<DetallePedido> detallepedido =new ArrayList<>();
    public void agregarDetallePedido(DetallePedido DetalleP){
        detallepedido.add(DetalleP);
    }
    public void mostrarDetallePedido(){
        System.out.println("Pedido de la fecha: " +fecha);
        for (DetallePedido Dpedido : detallepedido) {
            System.out.println("Cantidad: "+Dpedido.getCantidad()+"\nSubtotal: "+Dpedido.getSubtotal());
        }
    }



}

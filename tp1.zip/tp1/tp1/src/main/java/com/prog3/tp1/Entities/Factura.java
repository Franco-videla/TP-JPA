package com.prog3.tp1.Entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;


@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Factura extends baseEntidad {
    private LocalDateTime fecha;
    private int numero;
    private double descuento;
    @Enumerated(EnumType.STRING)
    private FormPago formaPago;
    private int total;
    public enum FormPago{
        EFECTIVO,ETC;
    }


}

package com.prog3.tp1;

import com.prog3.tp1.Entities.*;
import com.prog3.tp1.Repositories.*;
import jdk.swing.interop.SwingInterOpUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;

@SpringBootApplication
public class Tp1Application {

	@Autowired
	usuarioRepository usuarioRepository;
	@Autowired
	pedidoRepository pedidoRepository;
	@Autowired
	domicilioRepository domicilioRepository;
	@Autowired
	clienteRepository clienteRepository;
	@Autowired
	detallepedidoRepository detallepedidoRepository;
	@Autowired
	productoRepository productoRepository;
	@Autowired
	rubroRepository rubroRepository;

	public static void main(String[] args) {

		SpringApplication.run(Tp1Application.class, args);
		System.out.println("Funciona");
	}
	@Bean
	CommandLineRunner init(usuarioRepository usuariorepository, pedidoRepository pedidorepository, domicilioRepository domiciliorepository, clienteRepository clienterepository,detallepedidoRepository detallepedidorepository,productoRepository productorepository,rubroRepository rubrorepository) {
		return args -> {
			System.out.println("-----------------USUARIO HACE PEDIDO---------");
			//creo el pedido1
			Pedido pedido1 = Pedido.builder()
					.fecha("5 abril")
					.estado(Pedido.Estado.ENTREGADO)
					.tipoEnvio(Pedido.TipoEnvio.DELIBERY)
					.horaEstimadaEntrega(LocalDateTime.now())
					.total(10.000)
					.build();
			//creo el pedido2
			Pedido pedido2 = Pedido.builder()
					.fecha("5 mayo")
					.estado(Pedido.Estado.ENTREGADO)
					.tipoEnvio(Pedido.TipoEnvio.DELIBERY)
					.horaEstimadaEntrega(LocalDateTime.now())
					.total(10.000)
					.build();
			//creo el detalle de pedido1
			DetallePedido dPedido1 = DetallePedido.builder()
					.cantidad(10)
					.subtotal(50.23)
					.build();
			//creo el usuario1
			Usuario usuario1 = Usuario.builder()
					.nombre("Juan")
					.password("123")
					.rol("Programador")
					.build();
			//agrego el detalle de pedido1 en el pedido1
			pedido1.agregarDetallePedido(dPedido1);

			//guardo el pedido1 y pedido2 en el usuario1
			usuario1.agregarPedido(pedido1);
			usuario1.agregarPedido(pedido2);
			// Guardar el objeto Usuario en la base de datos
			usuariorepository.save(usuario1);
			// Recuperar el objeto Usuario desde la base de datos
			Usuario usuarioRecuperada = usuariorepository.findById(usuario1.getId()).orElse(null);
			if (usuarioRecuperada != null) {
				System.out.println("------USUARIO QUE HACE EL PEDIDO----------");
				System.out.println("Nombre: " + usuarioRecuperada.getNombre());
				System.out.println("Password: " + usuarioRecuperada.getPassword());
				System.out.println("rol: " + usuarioRecuperada.getRol());
				System.out.println("------PEDIDO DEL USUARIO----------");
				//muestro el pedido del usuario1
				usuarioRecuperada.mostrarPedidos();
				//muestro el pedido1
				System.out.println("------DETALLE DEL PEDIDO DEL USUARIO----------");
				pedido1.mostrarDetallePedido();
				System.out.println(" ------ finalice desde usuario");
			}
			//genero una factura
			System.out.println("-----------------CLIENTE HACE PEDIDO---------");
			Factura factura1 = Factura.builder()
					.fecha(LocalDateTime.of(2023,11,10,2,55,16))
					.formaPago(Factura.FormPago.EFECTIVO)
					.numero(20)
					.total(10000)
					.descuento(1000)
					.build();
			//genero pedido4
			Pedido pedido4 = Pedido.builder()
					.fecha("1 enero")
					.estado(Pedido.Estado.PREPARACION)
					.tipoEnvio(Pedido.TipoEnvio.RETIRADA)
					.horaEstimadaEntrega(LocalDateTime.now())
					.total(1.000)
					.build();
			pedido4.setFactura(factura1);
			//genero cliente1
			Cliente cliente1 = Cliente.builder()
					.nombre("Juan")
					.apellido("Equis")
					.telefono("261261261")
					.email("JX@gmail.com")
					.build();
			//guardo el pedido4 en el cliente
			cliente1.agregarPedidoC(pedido4);
			// creo el detalle de pedido2
			DetallePedido dPedido2 = DetallePedido.builder()
					.subtotal(5.000)
					.cantidad(5)
					.build();
			//creo el rubro1
			Rubro rubro1 =  Rubro.builder()
					.denominacion("Argentina.SA")
					.build();
			//creo el producto1
			Producto prod1 = Producto.builder()
					.foto("foto1")
					.denominacion("Natural")
					.precioCompra(50.000)
					.precioVenta(70.000)
					.tipo(Producto.tipo.MANUFACTURADO)
					.receta("Verduras")
					.stockActual(100)
					.stockMinimo(5)
					.tiempoEstimadoCocina(40)
					.unidadMedida("Alimento")
					.build();
			//guardo el producto1 uno en el detalle del pedido2
			dPedido2.setProducto(prod1);
			//guardo el producto1 en el rubro1
			rubro1.agregarProducto(prod1);
			//guardo el objeto Rubro1 en la base de adtos
			rubrorepository.save(rubro1);
			// Recuperar el objeto Rubro1 desde la base de datos
			//guardo el detalle de pedido2 en el pedido4
			pedido4.agregarDetallePedido(dPedido2);
			// Guardar el objeto cliente en la base de datos
			clienterepository.save(cliente1);
			// Recuperar el objeto cliente desde la base de datos
			Cliente clienteRecuperado = clienterepository.findById(cliente1.getId()).orElse(null);
			if (clienteRecuperado != null) {
				System.out.println("------CLIENTE QUE HACE EL PEDIDO----------");
				System.out.println("Nombre: " + clienteRecuperado.getNombre());
				System.out.println("apellido: " + clienteRecuperado.getApellido());
				System.out.println("Telefono: " + clienteRecuperado.getTelefono());
				System.out.println("Email: " + clienteRecuperado.getEmail());
				System.out.println("------PEDIDO DEL CLIENTE----------");
				//muestro el pedido4
					clienteRecuperado.mostrarPedidosC();
				System.out.println("------RUBRO DEL PEDIDO----------");
				Rubro rubroRecuperada = rubrorepository.findById(rubro1.getId()).orElse(null);
				if (rubroRecuperada != null) {
					System.out.println("DENOMINACION: "+ rubroRecuperada.getDenominacion());
					System.out.println("------PRODUCTOS DEL PEDIDO----------");
					//muestro el rubro1 y el producto1
					rubroRecuperada.mostrarProducto();
					System.out.println("------DETALLE DEL PEDIDO----------");
					pedido4.mostrarDetallePedido();
				}

					System.out.println(" ------ finalice desde cliente");
			}
				System.out.println("-----------------DOMICILIO HACE PEDIDO---------");
				//creo el domicilio1
				Domicilio domicilio1 = Domicilio.builder()
						.calle("Huarpes")
						.numero("1861")
						.localidad("Ciudad")
						.build();
			//creo el pedido3
				Pedido pedido3 = Pedido.builder()
						.fecha("15 junio")
						.estado(Pedido.Estado.ENTREGADO)
						.tipoEnvio(Pedido.TipoEnvio.DELIBERY)
						.horaEstimadaEntrega(LocalDateTime.now())
						.total(5.000)
						.build();
			//agrego el pedido3 en el domicilio1
				domicilio1.agregarPedidoD(pedido3);
				//agrego el cliente1 al domicilio1
				domicilio1.setCliente(cliente1);
				//guardo el objeto Domicilio en la base de datos
				domiciliorepository.save(domicilio1);
				//Recupero el objeto Domicilio de la base de datos
				Domicilio domicilioRecuperada = domiciliorepository.findById(domicilio1.getId()).orElse(null);
				if (domicilioRecuperada != null) {
					System.out.println("Calle: " + domicilioRecuperada.getCalle());
					System.out.println("Numero: " + domicilioRecuperada.getNumero());
					System.out.println("Localidad : " + domicilioRecuperada.getLocalidad());

					System.out.println("------PEDIDO DEL DOMICILIO----------");
					//Muestro el pedido del domicilio1
					domicilioRecuperada.mostrarPedidosD();
					System.out.println("------CLIENTE DEL DOMICILIO----------");
					//muestro el cliente del domicilio
					System.out.println(domicilioRecuperada.getCliente());
					System.out.println(" ------ finalice desde domicilio");
				}




		};
	}
}
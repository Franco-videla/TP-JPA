package com.prog3.tp1.Entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Usuario extends baseEntidad {

    @Column(name = "nombre")
    private String nombre;
    private String password;
    private String rol;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.EAGER)
    @JoinColumn(name = "usuario_id")
    @Builder.Default
    private List<Pedido> pedidos =new ArrayList<>();

    public void agregarPedido(Pedido pedi){
        pedidos.add(pedi);
    }
    public void mostrarPedidos(){
        System.out.println("Pedidos de " + nombre);
        for (Pedido pedido : pedidos) {
            System.out.println("Fecha: " + pedido.getFecha() + "\nEstado: " +pedido.getEstado()+"\nhora estimada de la entrega: "+pedido.getHoraEstimadaEntrega());
            System.out.println("Tipo de envio: "+pedido.getTipoEnvio()+"\nTotal: "+pedido.getTotal());
        }
    }
}
